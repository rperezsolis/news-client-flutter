const String newsApiKey = "ca7123f000284649993773fde0e7a696";
const String baseUrl = "newsapi.org";
const String topHeadlinesEndpoint = "/v2/top-headlines";