package com.example.rafaelperez.news_client

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
